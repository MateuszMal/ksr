public class DatabaseCreator {

    public void create_text_database(TextsContainer texts_container, String text)
    {
        SampleExtractor sample_extractor = new SampleExtractor();
        String processed_text = text;
        processed_text = StringFormatter.remove_separators(processed_text);

        String single_text;
        int position;

        while(processed_text.contains("</REUTERS>") == true)
        {
            position = sample_extractor.article_end_position(processed_text);

            single_text = processed_text.substring(0,position);
            processed_text = processed_text.substring(position);

            if(single_text.contains("<BODY>") && single_text.contains("</REUTERS>"))
            {

                String category = sample_extractor.extract_string("category", single_text);


                if(category.equals("usa") == true ||
                        category.equals("west-germany") == true ||
                        category.equals("france") == true ||
                        category.equals("uk") == true ||
                        category.equals("canada") == true ||
                        category.equals("japan") == true
                )
                {
                    String body = sample_extractor.extract_string("body", single_text);
                    texts_container.addText(new Text(category, body));
                }
            }

        }

    }

    public void create_text_database2(TextsContainer texts_container, String text)
    {
        SampleExtractor sample_extractor = new SampleExtractor();
        String processed_text = text;
        processed_text = StringFormatter.remove_separators(processed_text);

        String single_text;
        int position;

        while(processed_text.contains("</REUTERS>") == true)
        {
            position = sample_extractor.article_end_position(processed_text);

            single_text = processed_text.substring(0,position);
            processed_text = processed_text.substring(position);

            if(single_text.contains("<BODY>") && single_text.contains("</REUTERS>"))
            {

                String category = sample_extractor.extract_string("category", single_text);


                if(texts_container.get_texts_hash_map().containsKey(category))
                {
                    String body = sample_extractor.extract_string("body", single_text);
                    texts_container.get_texts_hash_map().get(category).add(body);
                }
            }

        }

    }


}
