import java.util.ArrayList;
import java.util.HashMap;

public class Commons {

    public static String create_whole_text_string(HashMap<String, ArrayList<String>> texts_hash){
        String output = "";
        for (String category : texts_hash.keySet())
        {
            for(int i = 0; i < texts_hash.get(category).size(); i ++)
            {
                output = output + texts_hash.get(category).get(i) + " ";
            }
        }
        return output;
    }

    public static String [] generate_country_array(HashMap<String, ArrayList<String>> texts_hash)
    {
        String output = "";

        for ( String key : texts_hash.keySet() ) {
            output = output + key + " ";
        }

        String [] country_array = output.split(" ");

        return country_array;
    }

}
