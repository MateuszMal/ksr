import java.util.regex.*;

public class SampleExtractor {

    String regex;
    Pattern pattern;
    Matcher matcher;

    public String extract_string(String type, String text)
    {


        if(type.compareTo("category") == 0)
        {
            regex = "<PLACES><D>(.+?)</D></PLACES>";
        }
        else if (type.compareTo("body") == 0)
        {
            regex = "<BODY>(.+?)</BODY>";
        }
        else
        {
            throw new java.lang.Error("no such category");
        }
        pattern = Pattern.compile(regex, Pattern.DOTALL);
        matcher = pattern.matcher(text);
        if(matcher.find())
        {
            return matcher.group(1);
        }
        else return " ";

    }

    public int article_end_position(String text)
    {
        pattern = Pattern.compile("</REUTERS>");
        matcher = pattern.matcher(text);
        matcher.find();
        return matcher.end();
    }

}
