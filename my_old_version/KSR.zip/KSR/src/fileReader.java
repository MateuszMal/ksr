import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Stream;

public class fileReader {

    public static String create_text_string(String directory_path) throws IOException {
        String line;
        String text = "";

        Object[] test;

        try (
                Stream<Path> paths = Files.walk(Paths.get(directory_path))) {

            test = paths.filter(Files::isRegularFile).toArray();
        }

        for (int i = 0; i < test.length; i++) {


        File file = new File(test[i].toString());

        try {
            FileReader fileReader = new FileReader(file);
            BufferedReader bfReader = new BufferedReader(fileReader);
            while ((line = bfReader.readLine()) != null) {
                text = text + " " + line;
            }

            bfReader.close();
        } catch (FileNotFoundException e) {
            System.err.println("File does not exist");
        } catch (IOException e) {
            System.err.println("File exists, but there was IOException");
        }

    }
        return text;
    }

}
