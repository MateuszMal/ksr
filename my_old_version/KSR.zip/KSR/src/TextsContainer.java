import java.util.ArrayList;
import java.util.HashMap;

public class TextsContainer {

    public TextsContainer()
    {
        texts = new ArrayList<Text>();
        texts_hash = new HashMap<>();
        texts_hash.put("usa", new ArrayList<String>());
        texts_hash.put("uk", new ArrayList<String>());
        texts_hash.put("france", new ArrayList<String>());
        texts_hash.put("west-germany", new ArrayList<String>());
        texts_hash.put("japan", new ArrayList<String>());
        texts_hash.put("canada", new ArrayList<String>());
    }

    private ArrayList<Text> texts;
    private HashMap<String, ArrayList<String>> texts_hash;

    public void addText(Text text)
    {
        texts.add(text);

    }

    public HashMap<String, ArrayList<String>> get_texts_hash_map(){return texts_hash;}

    public ArrayList<Text> getTexts() {
        return texts;
    }

    public void print_texts()
    {
        for (int i = 0; i < texts.size(); i++)
        {
            texts.get(i).print_text();
        }
    }

    public void print_texts2()
    {
        for (String category : texts_hash.keySet())
        {
            System.out.println("category: " + category);
            for(int i = 0; i < texts_hash.get(category).size(); i ++)
            {
                System.out.println(texts_hash.get(category).get(i) + " ");
            }
            System.out.println();

        }
    }

    public String create_whole_text_string(){
        String output = "";
        for (String category : texts_hash.keySet())
        {
            //System.out.println("category: " + category);
            for(int i = 0; i < texts_hash.get(category).size(); i ++)
            {
                output = output + texts_hash.get(category).get(i) + " ";
                //System.out.println(texts_hash.get(category).get(i) + " ");
            }
            //System.out.println();

        }
        return output;
    }

    public int get_size()
    {
        return texts.size();
    }

    public String all_texts_to_string()
    {
        String output = "";
        for (int i = 0; i < texts.size(); i ++)
        {
            output = output + texts.get(i).get_body() + " ";
        }
        return output;
    }


}
