import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Stream;

public class main {


    public static void main (String [] args) throws IOException {
        System.out.println("START");

        String path = "C:/Users/Bu/Desktop/Programowanie/Java/KSR/1";

        String text = fileReader.create_text_string(path);

        DatabaseCreator creator = new DatabaseCreator();

        TextsContainer container = new TextsContainer();

        creator.create_text_database2(container, text);

        container.print_texts2();

        String whole_text = Commons.create_whole_text_string(container.get_texts_hash_map());
        System.out.println(whole_text);

        String test [] = Commons.generate_country_array(container.get_texts_hash_map());

        for (int i = 0; i < test.length; i ++)
        {
            System.out.println(test[i]);
        }

        StringFormatter.format_whole_hash_map(container.get_texts_hash_map());

        WordOccurrenceMatrix matrix = new WordOccurrenceMatrix(container.get_texts_hash_map());

        matrix.print_matrix();

        matrix.count_for_whole_database2(container.get_texts_hash_map());

        matrix.print_matrix();

        System.out.println(matrix.get_word_that_occurred_the_most("usa"));


       // matrix.count_for_whole_database(container.get_texts_hash_map());


        //String whole_text = container.create_whole_text_string();

        //System.out.println("Size: " + container.get_size());

        /*String texts = container.all_texts_to_string();
        texts = StringFormatter.remove_separators(texts);
        System.out.println(texts);

        WordOccurrenceMatrix matrix = new WordOccurrenceMatrix(texts, WordOccurrenceMatrix.generate_country_array());
        matrix.count_for_whole_database(container);
        matrix.print_matrix();

        System.out.println(matrix.get_word_that_occurred_the_most("usa"));*/

    }

}
