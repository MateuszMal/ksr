public class Text {

    private String category;
    private String body;

    public Text(String category, String body){
        this.category = category;
        this.body = body;
    }

    public void print_text(){
        System.out.println();
        System.out.println("category: " + category);
        System.out.println("body: " + body);
    }

    public String get_body()
    {
        return body;
    }
    public String get_category(){return category;}

}
