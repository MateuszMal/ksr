import java.util.regex.*;

public class RegexTest {

}
